# Composante - Scrolly

Introduction de la composante Scrolly qui nous permet d'ajouter des animations d'apparition à nos éléments avec du CSS
<br><br>

## **Consigne de l'exercice**

Lien youtube: https://youtu.be/y95l5EeZZKI

<br><br>

# Stack de développement frontend TimTools

C'est quoi un stack de développement frontend? C'est un ensemble d'outil qui permet d'automatiser certaines tâches redondantes et plus complexe afin de d'accélérer et d'optmiser le développement d'un site web ou une application.

<hr><br>
Préparé par : Jean-François Leblanc et Matthieu Parent _timtools v1.22.0_
